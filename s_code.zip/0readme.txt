files           contents
-----           --------
Makefile        for Visual C++ and nmake
qui.c           sort: quicksort
qsort.c         sort: qsort
ins.c           sort: insert sort
shl.c           sort: shell sort
has.c           dictionary: hash tables
bin.c           dictionary: binary tree
rbt.c           dictionary: red-black trees
skl.c           dictionary: skip lists
ext.c           external sort
btr.c           btree
