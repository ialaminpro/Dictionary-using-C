#include <iostream>
#include <map>
using namespace std;

int main(int argc, char **argv) {
    int maxnum, ct;

    // command-line:
    //
    //   rbtcpp 2000
    //       process 2000 records

    maxnum = atoi(argv[1]);
    cout << "maxnum = " << maxnum << endl;

    typedef map<int,int> Collection;
    Collection c;
    Collection::iterator pos;

    for (int ct = maxnum; ct; ct--) {
        int key = rand() % 90 + 1;

        pos = c.find(key);
        if (pos != c.end()) {

            // found an existing node
            if (pos->second != 10*key)
                cout << "error: key = " << pos->first << ", value = " << pos->second << endl;

            // erase node in map
            c.erase(pos);

        } else {

            // create a new node
            c.insert(make_pair(key, 10*key));
        }
    }

    // output nodes in order
    for (pos = c.begin(); pos != c.end(); pos++)
        cout << "node: key = " << pos->first << ", value = " << pos->second << endl;

	// delete tree
	c.clear();

    return 0;
}
